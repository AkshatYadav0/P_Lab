# Welcome to the project page

This is a implementation of GRU network with attention layer.

```{tableofcontents}
```
